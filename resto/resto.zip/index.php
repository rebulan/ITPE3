<script>
	window.location.href = 'main.php';
</script>